package io.javabrains.topic;

import org.springframework.data.repository.CrudRepository;

// Topic = Type of Object-Elements, String = Type of ID
// Wieso Interface und keine Klasse?
public interface TopicRepository extends CrudRepository<Topic, String> {

}
