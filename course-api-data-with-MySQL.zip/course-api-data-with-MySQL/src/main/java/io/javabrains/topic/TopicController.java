package io.javabrains.topic;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TopicController {

	// autowired says that dependency injection is needs
	@Autowired
	private TopicService topicService;
	
	// @RequestMapping("/topics")
	// public String getAllTopics(){
	// 	return "All Topics";
	// }
	
	// default is get method
	@RequestMapping("/topics")
	public List<Topic> getAllTopics(){
		return topicService.getAllTopics();
	}
	
	// Mapping Parameter kann auch einen andere Namen haben, als in der Methode angegeben,
	// dann hinter PathVariable den Mapping Parameter Namen angegeben.
	// public Topic getTopic(@PathVariabe("id") String id){
	@RequestMapping("/topics/{id}")
	public Topic getTopic(@PathVariable String id){
		return topicService.getTopic(id);
	}
	
	// Request Payload und Body?
	@RequestMapping(method=RequestMethod.POST, value="/topics")
	public void addTopic(@RequestBody Topic topic){
		topicService.addTopic(topic);
	}
	
	//@RequestBody spiegelt das geänderte Topic Object wieder bzw. den JSON-Body
	@RequestMapping(method=RequestMethod.PUT, value="/topics/{id}")
	public void updateTopic(@RequestBody Topic topic, @PathVariable String id){
		topicService.updateTopic(id, topic);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/topics/{id}")
	public void deleteTopic(@PathVariable String id){
		topicService.deleteTopic(id);
	}
}
