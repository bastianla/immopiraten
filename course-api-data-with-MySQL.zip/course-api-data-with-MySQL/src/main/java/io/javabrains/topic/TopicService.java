package io.javabrains.topic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// singleton instance scope
@Service
public class TopicService {

	@Autowired
	private TopicRepository topicRepository;
	
	/*private List<Topic> topics = new ArrayList<>(Arrays.asList(
			new Topic("ID1", "Name1", "Description1"),
			new Topic("ID2", "Name2", "Description2"),
			new Topic("ID3", "Name3", "Description3"),
			new Topic("ID4", "Name4", "Description4"),
			new Topic("ID5", "Name5", "Description5")
		));*/
	
	public List<Topic> getAllTopics() {
		// return topics;
		List<Topic> topics = new ArrayList<>();
		topicRepository.findAll()
		.forEach(topics::add);
		return topics;
	}
	
	public Topic getTopic(String id){
		// returns the topic of the id
		// return topics.stream().filter(t -> t.getId().equals(id)).findFirst().get();
		return this.topicRepository.findOne(id);
	}

	public void addTopic(Topic topic) {
		// topics.add(topic);
		this.topicRepository.save(topic);
	}

	public void updateTopic(String id, Topic topic) {
		/*for (int i = 0; i < topics.size(); i++){
			Topic t = topics.get(i);
			if (t.getId().equals(id)){
				topics.set(i,  topic);
				return;
			}
		}*/
		// Save implements the save and update method
		// Auf Basis des PK bzw. der ID im topic weiß spring, ob die ID schon vorhanden ist
		// und somit ob ein Update oder Insert zu machen ist.
		this.topicRepository.save(topic);
	}

	public void deleteTopic(String id) {
		// topics.removeIf(t -> t.getId().equals(id));
		this.topicRepository.delete(id);
	}
}
