package io.javabrains.course;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.javabrains.topic.Topic;

@RestController
public class CourseController {

	// autowired says that dependency injection is needs
	@Autowired
	private CourseService courseService;
	
	// @RequestMapping("/topics")
	// public String getAllTopics(){
	// 	return "All Topics";
	// }
	
	// default is get method
	@RequestMapping("/topics/{id}/courses")
	public List<Course> getAllCourses(@PathVariable String id){
		return courseService.getAllCourses(id);
	}
	
	// Mapping Parameter kann auch einen andere Namen haben, als in der Methode angegeben,
	// dann hinter PathVariable den Mapping Parameter Namen angegeben.
	// public Topic getTopic(@PathVariabe("id") String id){
	@RequestMapping("/topics/{topicId}/courses/{id}")
	// @RequestMapping("/topics/courses/{id}")
	public Course getCourse( @PathVariable String id){
		return courseService.getCourse(id);
	}
	
	// Request Payload und Body?
	@RequestMapping(method=RequestMethod.POST, value="/topics/{topicId}/courses")
	public void addCourse(@RequestBody Course course, @PathVariable String topicId){
		course.setTopic(new Topic(topicId, "", ""));
		courseService.addCourse(course);
	}
	
	//@RequestBody spiegelt das geänderte Topic Object wieder bzw. den JSON-Body
	@RequestMapping(method=RequestMethod.PUT, value="/topics/{topicId}/courses/{id}")
	public void updateTopic(@RequestBody Course course, @PathVariable String topicId, @PathVariable String id){
		course.setTopic(new Topic(topicId, "", ""));
		courseService.updateCourse(course);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/topics/{topicId}/courses/{id}")
	public void deleteTopic(@PathVariable String id){
		courseService.deleteCourse(id);
	}
}
