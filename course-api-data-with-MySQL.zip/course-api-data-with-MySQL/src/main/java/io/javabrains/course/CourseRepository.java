package io.javabrains.course;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

// Topic = Type of Object-Elements, String = Type of ID
// Wieso Interface und keine Klasse?
public interface CourseRepository extends CrudRepository<Course, String> {

	// You don'T have to implement the method! Just declare the method with the
	// findByPropert name format, and Spring Data JPA will implement the method for you.
	public List<Course> findByName(String name);
	public List<Course> findByDescription(String description);
	
	// Name des Objectes + PK-Attribut in dem Object (write the method in camel case)
	public List<Course> findByTopicId(String topicId);
}
