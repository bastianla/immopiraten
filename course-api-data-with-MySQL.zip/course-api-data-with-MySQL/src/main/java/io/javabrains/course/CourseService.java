package io.javabrains.course;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// singleton instance scope
@Service
public class CourseService {

	@Autowired
	private CourseRepository courseRepository;
	
	/*private List<Topic> topics = new ArrayList<>(Arrays.asList(
			new Topic("ID1", "Name1", "Description1"),
			new Topic("ID2", "Name2", "Description2"),
			new Topic("ID3", "Name3", "Description3"),
			new Topic("ID4", "Name4", "Description4"),
			new Topic("ID5", "Name5", "Description5")
		));*/
	
	public List<Course> getAllCourses(String topicId) {
		// return topics;
		List<Course> courses = new ArrayList<>();
		courseRepository.findByTopicId(topicId)
		.forEach(courses::add);
		return courses;
	}
	
	public Course getCourse(String id){
		// returns the topic of the id
		// return topics.stream().filter(t -> t.getId().equals(id)).findFirst().get();
		return this.courseRepository.findOne(id);
	}

	public void addCourse(Course course) {
		// topics.add(topic);
		this.courseRepository.save(course);
	}

	public void updateCourse(Course course) {
		/*for (int i = 0; i < topics.size(); i++){
			Topic t = topics.get(i);
			if (t.getId().equals(id)){
				topics.set(i,  topic);
				return;
			}
		}*/
		// Save implements the save and update method
		// Auf Basis des PK bzw. der ID im topic weiß spring, ob die ID schon vorhanden ist
		// und somit ob ein Update oder Insert zu machen ist.
		this.courseRepository.save(course);
	}

	public void deleteCourse(String id) {
		// topics.removeIf(t -> t.getId().equals(id));
		this.courseRepository.delete(id);
	}
}
